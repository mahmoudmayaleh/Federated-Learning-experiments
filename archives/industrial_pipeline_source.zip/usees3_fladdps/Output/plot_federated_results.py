import json
import pandas as pd
import matplotlib.pyplot as plt

# Define paths
files = {
    "Client 1": "FedProx/flclient_1/runtime_analysis_history.json",
    "Client 2": "FedProx/flclient_2/runtime_analysis_history.json",
    "Client 3": "FedProx/flclient_3/runtime_analysis_history.json"
}

plt.figure(figsize=(12, 7))

for label, filepath in files.items():
    with open(filepath, 'r') as f:
        data = json.load(f)

    df = pd.DataFrame(data)

    # Group by round_no and average values to avoid duplicates
    df_grouped = df.groupby('round_no', as_index=False)['average_MSE'].mean()
    df_grouped.sort_values("round_no", inplace=True)

    plt.plot(df_grouped["round_no"].to_numpy(), df_grouped["average_MSE"].to_numpy(), marker='o', label=label)

plt.title("Average MSE per Round per Client")
plt.xlabel("Round Number")
plt.ylabel("Average MSE")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

