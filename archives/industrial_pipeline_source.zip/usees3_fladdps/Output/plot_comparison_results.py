import json
import pandas as pd
import matplotlib.pyplot as plt

# Define the paths to your files
methods = {
    "FedAvg": {
        "Client 1": "FedAvg/flclient_1/runtime_analysis_history.json",
        "Client 2": "FedAvg/flclient_2/runtime_analysis_history.json",
        "Client 3": "FedAvg/flclient_3/runtime_analysis_history.json",
    },
    "FedProx": {
        "Client 1": "FedProx/flclient_1/runtime_analysis_history.json",
        "Client 2": "FedProx/flclient_2/runtime_analysis_history.json",
        "Client 3": "FedProx/flclient_3/runtime_analysis_history.json",
    },
    "SCAFFOLD": {
        "Client 1": "Scaffold/flclient_1/runtime_analysis_history.json",
        "Client 2": "Scaffold/flclient_2/runtime_analysis_history.json",
        "Client 3": "Scaffold/flclient_3/runtime_analysis_history.json",
    }
}

plt.figure(figsize=(12, 7))

for method, clients in methods.items():
    all_dfs = []
    for client_name, path in clients.items():
        try:
            with open(path, "r") as f:
                data = json.load(f)
                df = pd.DataFrame(data)
                df["round_no"] = pd.to_numeric(df["round_no"], errors='coerce')
                df["average_MSE"] = pd.to_numeric(df["average_MSE"], errors='coerce')
                all_dfs.append(df)
        except Exception as e:
            print(f"Error loading {path}: {e}")

    if all_dfs:
        merged_df = pd.concat(all_dfs)
        avg_df = merged_df.groupby("round_no")["average_MSE"].mean().reset_index()
        plt.plot(
            avg_df["round_no"].to_numpy(),
            avg_df["average_MSE"].to_numpy(),
            marker="o",
            label=method
        )

plt.title("Comparison of Federated Learning Methods (Average MSE)")
plt.xlabel("Round Number")
plt.ylabel("Average MSE")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

