import numpy as np
import tensorflow as tf
from keras.callbacks import Callback
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping


def keras_lstm_training(X, y ,epochs, model, batch_size= 64, verbose=1 ):
  print("----------------- THIS IS A TRAINING FUNCTION_____________________________")
  pass

