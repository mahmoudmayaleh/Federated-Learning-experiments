
class lstmObjts:
    def __init__(self, X_train_x, oderedColumn_x, scaler_x, feature_size_x, component_name_and_feature_count={}):
        self.X_train_x = X_train_x
        self.oderedColumn_x = oderedColumn_x
        self.scaler_x = scaler_x
        self.feature_size_x = feature_size_x
        self.component_name_and_feature_count = component_name_and_feature_count

