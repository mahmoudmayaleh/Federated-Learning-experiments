import os
print("Current working directory:", os.getcwd())
