import flwr as fl
from flwr.server.strategy import FedAvg
from flwr.server import ServerConfig, start_server
from flwr.common import Parameters, FitRes, EvaluateRes, Scalar
import json
import os
from typing import List, Optional, Tuple, Dict

# Global config
STRATEGY = "FedProx"  #"FedAvg" or "FedProx"
MU = 0.1 if STRATEGY == "FedProx" else 0.0
NUM_ROUNDS = 25

# Results tracking
results = {
    "round": [],
    "train_loss": [],
    "train_accuracy": [],
    "val_loss": [],
    "val_accuracy": [],
}


class FedAvgWithLogging(FedAvg):
    def aggregate_fit(self, rnd, results_client, failures):
        agg_params, _ = super().aggregate_fit(rnd, results_client, failures)

        # Training metrics aggregation
        losses = [res.metrics["train_loss"] for _, res in results_client if "train_loss" in res.metrics]
        accs = [res.metrics["train_accuracy"] for _, res in results_client if "train_accuracy" in res.metrics]
        avg_loss = sum(losses) / len(losses) if losses else 0.0
        avg_acc = sum(accs) / len(accs) if accs else 0.0

        results["round"].append(rnd)
        results["train_loss"].append(avg_loss)
        results["train_accuracy"].append(avg_acc)

        return agg_params, {"train_loss": avg_loss, "train_accuracy": avg_acc}

    def aggregate_evaluate(self, rnd, results_client, failures):
        agg_loss, _ = super().aggregate_evaluate(rnd, results_client, failures)

        accs = [res.metrics["accuracy"] for _, res in results_client if "accuracy" in res.metrics]
        avg_acc = sum(accs) / len(accs) if accs else 0.0

        results["val_loss"].append(agg_loss)
        results["val_accuracy"].append(avg_acc)

        return agg_loss, {"accuracy": avg_acc}

    def on_training_end(self, server, timeout):
        # Save to JSON
        os.makedirs("results", exist_ok=True)
        with open("results/fedprox_results.json", "w") as f:
            json.dump(results, f, indent=4)

        # Print all metrics after training ends
        print("\nFinal Training Results:")
        print(f"Rounds: {results['round']}")
        print(f"Train Loss: {results['train_loss']}")
        print(f"Train Accuracy: {results['train_accuracy']}")
        print(f"Validation Loss: {results['val_loss']}")
        print(f"Validation Accuracy: {results['val_accuracy']}")


class CustomFedProx(FedAvgWithLogging):
    def __init__(self, proximal_mu: float = 0.1, **kwargs):
        super().__init__(**kwargs)
        self.proximal_mu = proximal_mu


def main():
    strategy = (
        FedAvgWithLogging() if STRATEGY == "FedAvg"
        else CustomFedProx(proximal_mu=MU)
    )

    start_server(
        server_address="localhost:8080",
        config=ServerConfig(num_rounds=NUM_ROUNDS),
        strategy=strategy,
    )


if __name__ == "__main__":
    main()
