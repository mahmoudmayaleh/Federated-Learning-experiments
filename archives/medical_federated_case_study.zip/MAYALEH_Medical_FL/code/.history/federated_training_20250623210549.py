import flwr as fl
import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
import medmnist
from medmnist import INFO
from flwr.server import ServerConfig
from flwr.server.strategy import FedAvg, FedProx
import os

# Load data
train_dataset, val_dataset, test_dataset = load_data()

# Split data for clients (IID setting)
def get_client_data(client_id, num_clients):
    total_size = len(train_dataset)
    client_size = total_size // num_clients
    start = client_id * client_size
    end = start + client_size if client_id < num_clients - 1 else total_size
    return torch.utils.data.Subset(train_dataset, range(start, end))

# Define client
class FlowerClient(fl.client.NumPyClient):
    def __init__(self, model, train_loader, val_loader):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)

    def get_parameters(self, config=None):
        return [val.cpu().detach().numpy() for val in self.model.parameters()]

    def set_parameters(self, parameters):
        for param, val in zip(self.model.parameters(), parameters):
            param.data = torch.tensor(val)

    def fit(self, parameters, config):
        print(f"Client {os.environ.get('CLIENT_ID')} starting fit...")
        self.set_parameters(parameters)
        self.model.train()
        for epoch in range(2):  # Example: 2 local epochs
            for images, labels in self.train_loader:
                self.optimizer.zero_grad()
                outputs = self.model(images)
                loss = self.criterion(outputs, labels)
                loss.backward()
                self.optimizer.step()
        print(f"Client {os.environ.get('CLIENT_ID')} finished fit.")
        return self.get_parameters(), len(self.train_loader.dataset), {}

    def evaluate(self, parameters, config):
        print(f"Client {os.environ.get('CLIENT_ID')} starting evaluate...")
        self.set_parameters(parameters)
        self.model.eval()
        loss, correct = 0, 0
        with torch.no_grad():
            for images, labels in self.val_loader:
                outputs = self.model(images)
                loss += self.criterion(outputs, labels).item()
                correct += (outputs.argmax(1) == labels).type(torch.float).sum().item()
        print(f"Client {os.environ.get('CLIENT_ID')} finished evaluate.")
        return loss / len(self.val_loader.dataset), len(self.val_loader.dataset), {"accuracy": correct / len(self.val_loader.dataset)}

# Start Flower server
def main(strategy_name="FedAvg"):
    num_clients = 2
    clients = []
    for i in range(num_clients):
        client_data = get_client_data(i, num_clients)
        train_loader = DataLoader(client_data, batch_size=32, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
        model = SimpleCNN(num_classes=11)
        clients.append(FlowerClient(model, train_loader, val_loader))

    # Use ServerConfig for configuration
    server_config = ServerConfig(num_rounds=15, round_timeout=30)

    # Choose the strategy
    if strategy_name == "FedAvg":
        strategy = FedAvg()
    elif strategy_name == "FedProx":
        strategy = FedProx(mu=0.1)  # `mu` is the proximal term coefficient
    else:
        raise ValueError(f"Unknown strategy: {strategy_name}")

    # Start the Flower server with the selected strategy
    fl.server.start_server(
        server_address="localhost:8080",
        config=server_config,
        strategy=strategy,
    )

if __name__ == "__main__":
    # Change the strategy here to "FedProx" or "FedAvg"
    main(strategy_name="FedAvg")