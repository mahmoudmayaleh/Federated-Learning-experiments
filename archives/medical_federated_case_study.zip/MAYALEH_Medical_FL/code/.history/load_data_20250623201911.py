import medmnist
from medmnist import INFO, Evaluator
import numpy as np
from torchvision import transforms
from torch.utils.data import DataLoader, random_split
import torch

def load_data():
    # Load OrganSMNIST dataset
    data_flag = 'organmnist'
    info = INFO[data_flag]
    DataClass = getattr(medmnist, info['python_class'])

    # Download and preprocess the dataset
    train_dataset = DataClass(split='train', download=True, transform=transforms.ToTensor())
    test_dataset = DataClass(split='test', download=True, transform=transforms.ToTensor())

    # Split train dataset into train and validation
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_dataset, val_dataset = random_split(train_dataset, [train_size, val_size])

    return train_dataset, val_dataset, test_dataset