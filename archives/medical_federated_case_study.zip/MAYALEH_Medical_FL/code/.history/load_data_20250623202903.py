import medmnist
from medmnist import INFO, Evaluator
import numpy as np
from torchvision import transforms
from torch.utils.data import DataLoader, random_split
import torch

def load_data():
    # Load OrganSMNIST dataset
    data_flag = 'organmnist_axial'
    info = INFO[data_flag]
    DataClass = getattr(medmnist, info['python_class'])

    # Define transform to ensure 28x28 resolution
    transform = transforms.Compose([
        transforms.Resize((28, 28)),
        transforms.ToTensor()
    ])

    # Download and split the dataset
    train_dataset = DataClass(split='train', download=True, transform=transform)
    test_dataset = DataClass(split='test', download=True, transform=transform)
  
    train_size = int(0.8 * len(train_dataset))
    val_size = len(train_dataset) - train_size
    train_dataset, val_dataset = random_split(train_dataset, [train_size, val_size])

    return train_dataset, val_dataset, test_dataset



print(INFO.keys())