import flwr as fl
import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
import medmnist
from medmnist import INFO
from flwr.server import ServerConfig
from flwr.server.strategy import FedAvg, FedProx
import os
import json 


# Load data
train_dataset, val_dataset, test_dataset = load_data()

# Split data for clients (IID setting)
def get_client_data(client_id, num_clients):
    total_size = len(train_dataset)
    client_size = total_size // num_clients
    start = client_id * client_size
    end = start + client_size if client_id < num_clients - 1 else total_size
    return torch.utils.data.Subset(train_dataset, range(start, end))

# Define client
class FlowerClient(fl.client.NumPyClient):
    def __init__(self, model, train_loader, val_loader):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)

    def get_parameters(self, config=None):
        return [val.cpu().detach().numpy() for val in self.model.parameters()]

    def set_parameters(self, parameters):
        for param, val in zip(self.model.parameters(), parameters):
            param.data = torch.tensor(val)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        self.model.train()
        total_loss = 0
        total_samples = 0
        for images, labels in self.train_loader:
            if images.size(0) != labels.size(0):
                print(f"Skipping mismatched batch: inputs={images.size(0)}, labels={labels.size(0)}")
                continue
            self.optimizer.zero_grad()
            outputs = self.model(images)
            loss = self.criterion(outputs, labels.argmax(dim=1))
            loss.backward()
            self.optimizer.step()
            total_loss += loss.item() * images.size(0)
            total_samples += images.size(0)
        avg_loss = total_loss / total_samples
        return avg_loss, total_samples, {"accuracy": total_samples / len(self.train_loader.dataset)}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        self.model.eval()
        loss, correct = 0, 0
        with torch.no_grad():
            for images, labels in self.val_loader:
                outputs = self.model(images)
                loss += self.criterion(outputs, labels.argmax(dim=1)).item()
                correct += (outputs.argmax(1) == labels).type(torch.float).sum().item()
        accuracy = correct / len(self.val_loader.dataset)
        avg_loss = loss / len(self.val_loader.dataset)
        # Return results for this client
        return avg_loss, len(self.val_loader.dataset), {"accuracy": accuracy, "loss": avg_loss}

# Start Flower server
def main(strategy_name="FedAvg"):
    num_clients = 5
    num_rounds = 5
    results = []

    # Get the number of classes from the dataset info
    dataset_info = INFO["organsmnist"]  # Use the correct dataset key
    num_classes = len(dataset_info["label"])  # Number of classes

    for round_num in range(num_rounds):
        round_results = {"round": round_num + 1, "training": {}, "validation": {}}
        total_train_loss, total_train_accuracy = 0, 0
        total_val_loss, total_val_accuracy = 0, 0
        total_train_samples, total_val_samples = 0, 0

        for client_id in range(num_clients):
            # Simulate getting results from each client
            client_data = get_client_data(client_id, num_clients)
            train_loader = DataLoader(client_data, batch_size=32, shuffle=True, drop_last=True)
            val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False, drop_last=True)

            # Initialize the client with the correct number of classes
            client = FlowerClient(model=SimpleCNN(num_classes=num_classes), train_loader=train_loader, val_loader=val_loader)

            # Get the current model parameters
            parameters = client.get_parameters()

            # Simulate training
            train_loss, train_samples, train_metrics = client.fit(parameters=parameters, config=None)
            total_train_loss += train_loss * train_samples
            total_train_accuracy += train_metrics["accuracy"] * train_samples
            total_train_samples += train_samples

            # Simulate evaluation
            val_loss, val_samples, val_metrics = client.evaluate(parameters=parameters, config=None)
            total_val_loss += val_loss * val_samples
            total_val_accuracy += val_metrics["accuracy"] * val_samples
            total_val_samples += val_samples

        # Aggregate results for the round
        round_results["training"]["loss"] = total_train_loss / total_train_samples
        round_results["training"]["accuracy"] = (total_train_accuracy / total_train_samples) * 100  # Convert to percentage
        round_results["validation"]["loss"] = total_val_loss / total_val_samples
        round_results["validation"]["accuracy"] = (total_val_accuracy / total_val_samples) * 100  # Convert to percentage

        results.append(round_results)

    # Save all results to a single file
    with open("results_fedavg.json", "w") as f:
        json.dump(results, f, indent=4)

    print("Results saved to results_fedavg.json")

    server_config = ServerConfig(num_rounds=25)
    # Choose the strategy
    if strategy_name == "FedAvg":
        strategy = FedAvg()
    elif strategy_name == "FedProx":
        strategy = FedProx(mu=0.1)
    else:
        raise ValueError(f"Unknown strategy: {strategy_name}")

    # Start the Flower server
    fl.server.start_server(
        server_address="localhost:8080",
        config=server_config,
        strategy=strategy,
    )

if __name__ == "__main__":
    #"FedProx" or "FedAvg"
    main(strategy_name="FedAvg")