import medmnist
from medmnist import INFO

print(INFO.keys())