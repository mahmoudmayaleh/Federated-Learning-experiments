import flwr as fl
import os
import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
from flwr.client import NumPyClient

# Load and split data
def get_client_data(client_id, num_clients, train_dataset):
    total_size = len(train_dataset)
    client_size = total_size // num_clients
    start = client_id * client_size
    end = start + client_size if client_id < num_clients - 1 else total_size
    return torch.utils.data.Subset(train_dataset, range(start, end))

# Define FlowerClient
class FlowerClient(NumPyClient):
    def __init__(self, model, train_loader, val_loader):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)

    def get_parameters(self, config=None):
        return [val.cpu().detach().numpy() for val in self.model.parameters()]

    def set_parameters(self, parameters):
        for param, val in zip(self.model.parameters(), parameters):
            param.data = torch.tensor(val)

    def fit(self, parameters, config=None):
        self.set_parameters(parameters)
        self.model.train()
        for epoch in range(3):  # Train for 3 epochs
            for images, labels in self.train_loader:
                self.optimizer.zero_grad()
                loss = self.criterion(self.model(images), labels.argmax(dim=1))
                loss.backward()
                self.optimizer.step()
        return self.get_parameters(), len(self.train_loader.dataset), {}

    def evaluate(self, parameters, config=None):
        self.set_parameters(parameters)
        self.model.eval()
        loss, correct = 0.0, 0
        total = 0
        with torch.no_grad():
            for images, labels in self.val_loader:
                outputs = self.model(images)
                targets = labels.squeeze().long()
                loss += self.criterion(outputs, targets).item() * images.size(0)
                correct += (outputs.argmax(1) == targets).sum().item()
                total += images.size(0)
        return loss / total, total, {"accuracy": correct / total}

# Start client
def start_client(client_id, num_clients):
    train_dataset, val_dataset, _ = load_data()
    client_data = get_client_data(client_id, num_clients, train_dataset)
    train_loader = DataLoader(client_data, batch_size=64, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False, drop_last=True)
    model = SimpleCNN(num_classes=11)

    fl.client.start_client(
        server_address="localhost:8080",
        client=FlowerClient(model, train_loader, val_loader),
    )

if __name__ == "__main__":
    client_id = int(os.environ.get("CLIENT_ID", 0))
    num_clients = int(os.environ.get("NUM_CLIENTS", 5))
    start_client(client_id=client_id, num_clients=num_clients)
