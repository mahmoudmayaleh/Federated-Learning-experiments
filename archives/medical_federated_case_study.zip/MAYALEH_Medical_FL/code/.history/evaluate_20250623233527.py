import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
import json
import os

def evaluate_model(model, test_dataset):
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            targets = labels.squeeze().long()
            total += targets.size(0)
            correct += (predicted == targets).sum().item()

    accuracy = correct / total
    print(f"Test Accuracy: {accuracy * 100:.2f}%")

    os.makedirs("results", exist_ok=True)
    with open("results/test_fedprox_results.json", "w") as f:
        json.dump({"test_accuracy": accuracy}, f, indent=4)

if __name__ == "__main__":
    _, _, test_dataset = load_data()
    model = SimpleCNN(num_classes=11)

    # Load trained model weights
    if os.path.exists("fedprox_model.pth"):
        model.load_state_dict(torch.load("fedprox_model.pth"))
    else:
        print("WARNING: Trained model not found. Evaluation will run with random weights.")

    evaluate_model(model, test_dataset)
