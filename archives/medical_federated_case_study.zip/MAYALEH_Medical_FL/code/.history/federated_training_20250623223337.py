import flwr as fl
import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
import json
import numpy as np
from medmnist import INFO
from load_data import data_flag

# Load data
train_dataset, val_dataset, _ = load_data()

# Split data for clients (IID setting)
def get_client_data(client_id, num_clients):
    total_size = len(train_dataset)
    client_size = total_size // num_clients
    start = client_id * client_size
    end = start + client_size if client_id < num_clients - 1 else total_size
    return torch.utils.data.Subset(train_dataset, range(start, end))

# Define client
class FlowerClient:
    def __init__(self, model, train_loader, val_loader):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)

    def get_parameters(self):
        return [val.cpu().detach().numpy() for val in self.model.parameters()]

    def set_parameters(self, parameters):
        for param, val in zip(self.model.parameters(), parameters):
            param.data = torch.tensor(val)

    def fit(self, parameters):
        self.set_parameters(parameters)
        self.model.train()
        correct, total, total_loss = 0, 0, 0
        for epoch in range(1):  # One epoch per round per client
            for images, labels in self.train_loader:
                self.optimizer.zero_grad()
                outputs = self.model(images)
                targets = labels.argmax(dim=1)
                loss = self.criterion(outputs, targets)
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item() * images.size(0)
                correct += (outputs.argmax(1) == targets).sum().item()
                total += images.size(0)
        avg_loss = total_loss / total
        accuracy = correct / total
        return self.get_parameters(), avg_loss, accuracy

    def evaluate(self, parameters):
        self.set_parameters(parameters)
        self.model.eval()
        correct, total, total_loss = 0, 0, 0
        with torch.no_grad():
            for images, labels in self.val_loader:
                outputs = self.model(images)
                targets = labels.argmax(dim=1)
                loss = self.criterion(outputs, targets)
                total_loss += loss.item() * images.size(0)
                correct += (outputs.argmax(1) == targets).sum().item()
                total += images.size(0)
        avg_loss = total_loss / total
        accuracy = correct / total
        return avg_loss, accuracy

# Run simulation
def main(strategy_name="FedAvg"):
    num_clients = 5
    num_rounds = 25
    results = {"train_accuracy": [], "train_loss": [], "val_accuracy": [], "val_loss": []}
    NUM_CLASSES = len(INFO[data_flag]["label"])

    # Initialize clients
    clients = []
    for client_id in range(num_clients):
        client_data = get_client_data(client_id, num_clients)
        train_loader = DataLoader(client_data, batch_size=32, shuffle=True, drop_last=True)
        val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False, drop_last=True)
        clients.append(FlowerClient(model=SimpleCNN(num_classes=NUM_CLASSES), train_loader=train_loader, val_loader=val_loader))

    # Initialize global parameters
    global_params = clients[0].get_parameters()

    # Training loop
    for rnd in range(num_rounds):
        print(f"\n--- Round {rnd + 1} ---")
        round_train_losses = []
        round_train_accuracies = []
        round_val_losses = []
        round_val_accuracies = []

        # Fit each client
        client_params = []
        for client in clients:
            updated_params, train_loss, train_acc = client.fit(global_params)
            client_params.append(updated_params)
            round_train_losses.append(train_loss)
            round_train_accuracies.append(train_acc)

        # Aggregate parameters (FedAvg)
        new_params = []
        for param_i in range(len(global_params)):
            stacked = np.stack([client[param_i] for client in client_params], axis=0)
            avg = np.mean(stacked, axis=0)
            new_params.append(avg)
        global_params = new_params

        # Evaluate each client
        for client in clients:
            val_loss, val_acc = client.evaluate(global_params)
            round_val_losses.append(val_loss)
            round_val_accuracies.append(val_acc)

        # Aggregate and store metrics
        results["train_loss"].append(np.mean(round_train_losses))
        results["train_accuracy"].append(np.mean(round_train_accuracies))
        results["val_loss"].append(np.mean(round_val_losses))
        results["val_accuracy"].append(np.mean(round_val_accuracies))

        print(f"Train Acc: {results['train_accuracy'][-1]:.4f} | Val Acc: {results['val_accuracy'][-1]:.4f}")
        print(f"Train Loss: {results['train_loss'][-1]:.4f} | Val Loss: {results['val_loss'][-1]:.4f}")

    # Save results
    with open("results_fedavg.json", "w") as f:
        json.dump(results, f, indent=4)
    print("\nResults saved to results_fedavg.json")

if __name__ == "__main__":
    main(strategy_name="FedAvg")
