import json
import matplotlib.pyplot as plt

with open("results_fedavg.json", "r") as f:
    results = json.load(f)

rounds = list(range(1, len(results["train_loss"]) + 1))
train_loss = [loss[1] for loss in results["train_loss"]]
val_loss = [loss[1] for loss in results["val_loss"]]
train_accuracy = [acc[1] * 100 for acc in results["train_accuracy"]]  
val_accuracy = [acc[1] * 100 for acc in results["val_accuracy"]]    

# Plot Training and Validation Loss
plt.figure(figsize=(10, 6))
plt.plot(rounds, train_loss, label="Training Loss", marker="o")
plt.plot(rounds, val_loss, label="Validation Loss", marker="o")
plt.xlabel("Rounds")
plt.ylabel("Loss")
plt.title("FedAvg - Training and Validation Loss Across Rounds")
plt.legend()
plt.grid()
plt.show()

# Plot Training and Validation Accuracy
plt.figure(figsize=(10, 6))
plt.plot(rounds, train_accuracy, label="Training Accuracy", marker="o")
plt.plot(rounds, val_accuracy, label="Validation Accuracy", marker="o")
plt.xlabel("Rounds")
plt.ylabel("Accuracy (%)")
plt.title("FedAvg - Training and Validation Accuracy Across Rounds")
plt.legend()
plt.grid()
plt.show()