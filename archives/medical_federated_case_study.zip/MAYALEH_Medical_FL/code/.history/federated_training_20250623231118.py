import flwr as fl
from flwr.server.strategy import FedAvg
from flwr.server import ServerConfig
import json

# Tracking results
results = {"round": [], "val_accuracy": [], "val_loss": []}
STRATEGY = "FedProx"  # "FedAvg" or "FedProx"
MU = 0.1 if STRATEGY == "FedProx" else 0.0
NUM_ROUNDS = 25


# Custom strategy to log metrics
class FedAvgWithLogging(FedAvg):
    def aggregate_evaluate(self, rnd, results_client, failures):
        aggregated_loss, aggregated_metrics = super().aggregate_evaluate(rnd, results_client, failures)

        accs = [res.metrics["accuracy"] for _, res in results_client if "accuracy" in res.metrics]
        avg_acc = sum(accs) / len(accs) if accs else 0.0

        # Log results
        results["round"].append(rnd)
        results["val_accuracy"].append(avg_acc)
        results["val_loss"].append(aggregated_loss)

        print(f"[Round {rnd}] Val Acc: {avg_acc:.4f} | Val Loss: {aggregated_loss:.4f}")
        return aggregated_loss, {"accuracy": avg_acc}


    def on_round_end(self, server, rnd, timeout):
        # Save after every round
        with open("results.json", "w") as f:
            json.dump(results, f, indent=4)

# Main server launch
def main():
    strategy = FedAvg() if STRATEGY == "FedAvg" else FedProx(mu=0.1)

    fl.server.start_server(
        server_address="localhost:8080",
        config=fl.server.ServerConfig(num_rounds=NUM_ROUNDS),
        strategy=strategy,
    )

if __name__ == "__main__":
    main()
