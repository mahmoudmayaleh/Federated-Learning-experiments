import flwr as fl
import os
import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
from flwr.client import NumPyClient

STRATEGY = "FedProx"  # "FedAvg" or "FedProx"
MU = 0.1 if STRATEGY == "FedProx" else 0.0

def get_client_data(client_id, num_clients, train_dataset):
    total_size = len(train_dataset)
    client_size = total_size // num_clients
    start = client_id * client_size
    end = start + client_size if client_id < num_clients - 1 else total_size
    return torch.utils.data.Subset(train_dataset, range(start, end))

class FlowerClient(NumPyClient):
    def __init__(self, model, train_loader, val_loader, mu):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.001)
        self.mu = mu
        self.initial_params = None

    def get_parameters(self, config=None):
        return [val.cpu().detach().numpy() for val in self.model.parameters()]

    def set_parameters(self, parameters):
        for param, val in zip(self.model.parameters(), parameters):
            param.data = torch.tensor(val)
        if self.mu > 0:
            self.initial_params = [param.clone().detach() for param in self.model.parameters()]

    def fit(self, parameters, config=None):
      self.set_parameters(parameters)
      self.model.train()

      total_loss = 0.0
      correct = 0
      total_samples = 0

      for epoch in range(3):
          for images, labels in self.train_loader:
              self.optimizer.zero_grad()
              targets = labels.squeeze().long()
              outputs = self.model(images)
              loss = self.criterion(outputs, targets)

              # FedProx proximal term
              if hasattr(self, "mu") and self.mu > 0 and hasattr(self, "initial_params") and self.initial_params:
                  prox_term = sum(((param - init_param).norm(2) ** 2)
                                  for param, init_param in zip(self.model.parameters(), self.initial_params))
                  loss += (self.mu / 2) * prox_term

              loss.backward()
              self.optimizer.step()

              total_loss += loss.item() * images.size(0)
              correct += (outputs.argmax(1) == targets).sum().item()
              total_samples += images.size(0)

      return self.get_parameters(), total_samples, {
          "train_loss": total_loss / total_samples,
          "train_accuracy": correct / total_samples,
      }


    def evaluate(self, parameters, config=None):
        self.set_parameters(parameters)
        self.model.eval()
        loss, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for images, labels in self.val_loader:
                outputs = self.model(images)
                targets = labels.squeeze().long()
                loss += self.criterion(outputs, targets).item() * images.size(0)
                correct += (outputs.argmax(1) == targets).sum().item()
                total += images.size(0)
        return loss / total, total, {"accuracy": correct / total}

def start_client(client_id, num_clients):
    train_dataset, val_dataset, _ = load_data()
    client_data = get_client_data(client_id, num_clients, train_dataset)
    train_loader = DataLoader(client_data, batch_size=64, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False, drop_last=True)
    model = SimpleCNN(num_classes=11)
    fl.client.start_client(
        server_address="localhost:8080",
        client=FlowerClient(model, train_loader, val_loader, mu=MU).to_client(),
    )

if __name__ == "__main__":
    client_id = int(os.environ.get("CLIENT_ID", 0))
    num_clients = int(os.environ.get("NUM_CLIENTS", 5))
    start_client(client_id=client_id, num_clients=num_clients)
