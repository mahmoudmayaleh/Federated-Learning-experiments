import subprocess
import time
import os

NUM_CLIENTS = 5

processes = []

for client_id in range(NUM_CLIENTS):
    env = {
        **os.environ,
        "CLIENT_ID": str(client_id),  # Set CLIENT_ID for each client
        "NUM_CLIENTS": str(NUM_CLIENTS),
    }
    # Launch each client as a separate process
    p = subprocess.Popen(["python", "client.py"], env=env)
    processes.append(p)
    time.sleep(1)
print(f"Launched {NUM_CLIENTS} clients.")

# Wait for all processes to complete
for p in processes:
    p.wait()