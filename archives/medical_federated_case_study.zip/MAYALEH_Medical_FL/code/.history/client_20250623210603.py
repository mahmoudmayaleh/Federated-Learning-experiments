import flwr as fl
import os
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data
from federated_training import FlowerClient, get_client_data

def start_client(client_id, num_clients):
    # Load data
    train_dataset, val_dataset, _ = load_data()
    client_data = get_client_data(client_id, num_clients)
    train_loader = DataLoader(client_data, batch_size=32, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False, drop_last=True)

    model = SimpleCNN(num_classes=11)

    # Start Flower client
    client = FlowerClient(model, train_loader, val_loader)
    fl.client.start_numpy_client(server_address="localhost:8080", client=client)

if __name__ == "__main__":
    # Automatically determine client ID and number of clients
    client_id = int(os.environ.get("CLIENT_ID", 0)) 
    num_clients = int(os.environ.get("NUM_CLIENTS", 5)) 

    start_client(client_id=client_id, num_clients=num_clients)