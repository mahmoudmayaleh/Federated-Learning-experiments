import torch
from torch.utils.data import DataLoader
from model import SimpleCNN
from load_data import load_data

def evaluate_model(model, test_dataset):
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    print(f"Test Accuracy: {100 * correct / total:.2f}%")

if __name__ == "__main__":
    _, _, test_dataset = load_data()
    model = SimpleCNN(num_classes=11)
    evaluate_model(model, test_dataset)