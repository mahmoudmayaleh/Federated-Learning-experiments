# Federated Learning Robust Aggregation Experiments

This project implements and compares robust aggregation strategies for federated learning under adversarial attacks, including **FedAvg**, **FedMedian**, and **Krum**. You can simulate data/model poisoning, vary the percentage of malicious clients, and control data heterogeneity using the Dirichlet parameter α.

## Directory Structure

```
.
├── client_attack.py
├── client_manager.py
├── plot_attack.py
├── plot_attack_alpha.py
├── run_client_attack.py
├── run_clients_auto.py
├── run_server_attack.py
├── run_server_fedmedian.py
├── run_server_krum.py
├── strategy.py
├── TP3_results/
└── ...
```

## How to Run Experiments

### 1. Set Experiment Parameters

- **Malicious Ratio:** Set in `run_clients_auto.py` (e.g., `MALICIOUS_RATIO = 0.25` for 25% malicious clients).
- **Attack Type:** Set in `run_clients_auto.py` (e.g., `ATTACK_TYPE = "data"` or `"model"`).
- **Dirichlet α:** Set in each server script (e.g., `ALPHA_DIRICHLET = 10`, `1`, or `0.1`).
- **Other Hyperparameters:** (learning rate, batch size, etc.) are set in the server scripts.

### 2. Start the Server

Choose the aggregation strategy:

- **FedAvg:**
  ```
  python run_server_attack.py
  ```
- **FedMedian:**
  ```
  python run_server_fedmedian.py
  ```
- **Krum:**
  ```
  python run_server_krum.py
  ```

**Set `ALPHA_DIRICHLET` in the chosen server script before running.**

### 3. Start the Clients

In a separate terminal, run:

```
python run_clients_auto.py
```

This will launch all clients, with the correct proportion being malicious.

### 4. Results

Results are saved in the `TP3_results/` directory with filenames indicating the strategy, attack type, malicious ratio, and α value, e.g.:

- `server_history_fedavg_data_poisoning_10_alpha.json`
- `server_history_fedmedian_data_poisoning_10_alpha.json`
- `server_history_krum_data_poisoning_10_alpha.json`

### 5. Plotting

#### Compare α for a Single Strategy

Use `plot_attack_alpha.py` to compare the effect of different α values for a single strategy (e.g., Krum):

```python
python plot_attack_alpha.py
```

This script will plot loss and accuracy curves for α ∈ {10, 1, 0.1}.

#### Compare All Strategies for Fixed α

To compare FedAvg, FedMedian, and Krum for a fixed α (e.g., α=10) and attack type (e.g., data poisoning), use the following script:

```python
import json
import os
import matplotlib.pyplot as plt

results_dir = "TP3_results"
ATTACK_TYPE = "data"
alpha = 10

strategies = [
    ("FedAvg", f"server_history_fedavg_{ATTACK_TYPE}_poisoning_{alpha}_alpha.json", "#2b83ba"),
    ("FedMedian", f"server_history_fedmedian_{ATTACK_TYPE}_poisoning_{alpha}_alpha.json", "#fdae61"),
    ("Krum", f"server_history_krum_{ATTACK_TYPE}_poisoning_{alpha}_alpha.json", "#d7191c"),
]

loss_curves = []
acc_curves = []

for name, fname, color in strategies:
    path = os.path.join(results_dir, fname)
    if not os.path.exists(path):
        print(f"File not found: {path}")
        loss_curves.append((None, color, name))
        acc_curves.append((None, color, name))
        continue
    with open(path, "r") as f:
        history = json.load(f)
    loss = history.get("FL_loss", {})
    acc = history.get("FL_accuracy", {})
    rounds = sorted(loss.keys(), key=lambda x: int(x))
    loss_curves.append(([loss[r] for r in rounds], color, name))
    acc_curves.append(([acc[r] for r in rounds], color, name))

# Plot Loss
plt.figure(figsize=(10, 5))
for curve, color, name in loss_curves:
    if curve is not None:
        plt.plot(curve, label=name, color=color)
plt.title(f"Comparison (α={alpha}, 25% Data Poisoning): Training Loss per Round")
plt.xlabel("Round")
plt.ylabel("Loss")
plt.legend()
plt.grid()
plt.tight_layout()
plt.savefig(os.path.join(results_dir, f"comparison_loss_alpha_{alpha}_{ATTACK_TYPE}_poisoning.png"))
plt.show()

# Plot Accuracy
plt.figure(figsize=(10, 5))
for curve, color, name in acc_curves:
    if curve is not None:
        plt.plot(curve, label=name, color=color)
plt.title(f"Comparison (α={alpha}, 25% Data Poisoning): Test Accuracy per Round")
plt.xlabel("Round")
plt.ylabel("Accuracy")
plt.legend()
plt.grid()
plt.tight_layout()
plt.savefig(os.path.join(results_dir, f"comparison_accuracy_alpha_{alpha}_{ATTACK_TYPE}_poisoning.png"))
plt.show()
```

---

## Notes

- **Deprecation Warnings:** Flower may warn about deprecated APIs (`start_client`, `start_server`). The code will still work, but consider updating to the new CLI in the future.
- **Server Before Clients:** Always start the server before launching clients.
- **File Naming:** Ensure result files are named consistently for plotting scripts to work.
- **Custom Client Manager:** If using a custom client manager, ensure it is imported and used in the server scripts as needed.

---

## Experiment Checklist

For each α ∈ {10, 1, 0.1}:

- Set `ALPHA_DIRICHLET` in server script.
- Set `MALICIOUS_RATIO = 0.25` and `ATTACK_TYPE = "data"` in `run_clients_auto.py`.
- Run each server script (FedAvg, FedMedian, Krum) and collect results.
- Use plotting scripts to visualize and compare.
