# Federated Learning Strategies: FedAvg, FedProx, and SCAFFOLD

This project investigates the impact of data heterogeneity on federated learning using three strategies: **FedAvg**, **FedProx**, and **SCAFFOLD**. It includes code for running federated simulations, collecting results, and visualizing/analysing the performance of each strategy under different data heterogeneity settings.

---

## Project Structure

```
.
├── client.py                # Client implementation for all strategies
├── strategy.py              # Server-side strategy implementations (FedAvg, FedProx, SCAFFOLD)
├── run_server.py            # Script to launch the federated server
├── run_client.py            # Script to launch a federated client
├── TP2_results/             # Directory for storing experiment results (JSON)
├── TP2_figures/             # Directory for storing generated plots and summary tables
├── plot_fedavg_results.py   # Plotting script for FedAvg results
├── plot_fedprox_results.py  # Plotting script for FedProx results
├── plot_scaffold_results.py # Plotting script for SCAFFOLD results
├── compare_strategies_summary.py # Script to generate a summary table comparing all strategies
└── README.md                # This file
```

---

## How to Run

### 1. Install Requirements

Make sure you have Python 3.8+ and install dependencies:

```bash
pip install -r requirements.txt
```

If `requirements.txt` is missing, install the main packages manually:

```bash
pip install flwr numpy pandas matplotlib tabulate torch
```

### 2. Run Experiments

- **Start the server** (choose strategy in `run_server.py`):
  ```bash
  python run_server.py
  ```
- **Start clients** (in separate terminals, as many as needed):
  ```bash
  python run_client.py
  ```

### 3. Plot Results

After experiments, generate plots for each strategy:

```bash
python plot_fedavg_results.py
python plot_fedprox_results.py
python plot_scaffold_results.py
```

### 4. Compare Strategies

Generate a summary table (saved as PNG in `TP2_figures/`):

```bash
python compare_strategies_summary.py
```

---

## Output

- **Plots**: Training loss and test accuracy curves for each strategy and heterogeneity setting, saved in `TP2_figures/`.
- **Summary Table**: `strategies_summary_table.png` compares final accuracy, convergence speed, and training stability for all strategies and $\alpha$ values.

---

## Analysis

See the LaTeX report template (provided separately) for a detailed discussion of the results and answers to key research questions.

---

## Notes

- The Dirichlet $\alpha$ parameter controls data heterogeneity: lower $\alpha$ means more non-IID data.
- You can adjust the number of rounds, clients, and other hyperparameters in `run_server.py`.
- Make sure to clear old results in `TP2_results/` before running new experiments.

---

## License

This project is for educational and research purposes.
