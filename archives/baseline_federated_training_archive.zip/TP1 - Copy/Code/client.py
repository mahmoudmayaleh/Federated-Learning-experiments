import flwr as fl
import torch
import numpy as np
from flwr.common import (
    GetPropertiesIns, GetPropertiesRes,
    GetParametersIns, GetParametersRes,
    FitIns, FitRes, Status, Code,
    EvaluateIns, EvaluateRes,
    ndarrays_to_parameters,
    parameters_to_ndarrays,
)
from typing import List
from model import CustomFashionModel

class CustomClient(fl.client.Client):
    def __init__(self, model: torch.nn.Module, train_loader, test_loader, device: torch.device) -> None:
        self.model = model
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.device = device

    def get_properties(self, instruction: GetPropertiesIns) -> GetPropertiesRes:
        return GetPropertiesRes(
            status=Status(code=Code.OK, message="Success"),
            properties={"device": str(self.device)}
        )

    def get_parameters(self, instruction: GetParametersIns) -> GetParametersRes:
        params = self.model.get_model_parameters() # type: ignore
        return GetParametersRes(
            status=Status(code=Code.OK, message="Success"),
            parameters=ndarrays_to_parameters(params)
        )

    def fit(self, instruction: FitIns) -> FitRes:
        params = parameters_to_ndarrays(instruction.parameters)
        self.set_model_parameters(params)

        loss, acc = self.model.train_epoch(
            self.train_loader,
            torch.nn.CrossEntropyLoss(),
            torch.optim.SGD(self.model.parameters(), lr=0.01),
            self.device,
        ) # type: ignore
        updated_weights = self.model.get_model_parameters()  # type: ignore # <-- call model method here!
        return FitRes(
            status=Status(code=Code.OK, message="Success"),
            parameters=ndarrays_to_parameters(updated_weights),
            num_examples=len(self.train_loader.dataset),
            metrics={"FL_accuracy": acc, "FL_loss": loss},
        )

    def evaluate(self, instruction: EvaluateIns) -> EvaluateRes:
        params = parameters_to_ndarrays(instruction.parameters)
        self.set_model_parameters(params)

        loss, acc = self.model.test_epoch(
            self.test_loader,
            torch.nn.CrossEntropyLoss(),
            self.device,
        ) # type: ignore
        return EvaluateRes(
            status=Status(code=Code.OK, message="Success"),
            loss=float(loss),
            num_examples=len(self.test_loader.dataset),
            metrics={},
        )

    def to_client(self) -> "CustomClient":
        return self

    def get_model_parameters(self) -> List[np.ndarray]:
        return [val.cpu().numpy() for val in self.model.state_dict().values()]

    def set_model_parameters(self, parameters: List[np.ndarray]) -> None:
        params_dict = zip(self.model.state_dict().keys(), parameters)
        state_dict = {k: torch.tensor(v).to(self.device) for k, v in params_dict}
        self.model.load_state_dict(state_dict)
