from results_visualizer import ResultsVisualizer

SEED = 42
NUM_ROUNDS = 15
NUM_CLIENTS = 10
EPOCHS = 10
DATASET_NAME = "FashionMNIST"
ALPHA_DIRICHLET = 1
BATCH_SIZE = 32
LEARNING_RATE = 0.01
def main():
    visualizer = ResultsVisualizer()
    visualizer.load_simulation_results(f"server_history_{NUM_ROUNDS}_{EPOCHS}.json")
    visualizer.print_results_table()
    visualizer.plot_results("figures")


if __name__ == "__main__":
    main() 